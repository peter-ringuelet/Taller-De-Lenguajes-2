package parcial.fecha1;

public abstract class Gesto {
	public Gesto() {}
	
	public abstract void mostrar();
}

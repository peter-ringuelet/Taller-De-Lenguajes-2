package parcial.fecha1;

public class Piedra extends Gesto{

	public Piedra() {
		super();
	}
	
	public void mostrar() {
		System.out.println("Piedra");
	}
}

package parcial.fecha1;

public class Tijera extends Gesto{

	public Tijera() {
		super();
	}
	
	public void mostrar() {
		System.out.println("Tijera");
	}

}

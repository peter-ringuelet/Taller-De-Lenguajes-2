package parcial.fecha1;

public class Papel extends Gesto{

	public Papel() {
		super();
	}
	
	public void mostrar() {
		System.out.println("Papel");
	}

}
